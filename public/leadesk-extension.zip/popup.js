// ═══════════════════════════════════════════════════════════════
// Leadesk Extension — Popup Script v3.0
// ═══════════════════════════════════════════════════════════════

const SUPABASE_URL = 'https://jdhajqpgfrsuoluaesjn.supabase.co'
const SUPABASE_KEY = 'sb_publishable__KdQsVuSD6WWuswGcViaRw_CxDK8grx'
const DASHBOARD    = 'https://app.leadesk.de'

let currentProfile = null
let currentUserId  = null

// ── Helpers ───────────────────────────────────────────────────────
function getAuth() {
  return new Promise(r => chrome.storage.local.get(['supabaseSession', 'userId'], r))
}

function show(id)  { document.getElementById(id).style.display = '' }
function hide(id)  { document.getElementById(id).style.display = 'none' }

function setStatus(type, text) {
  const dot  = document.getElementById('statusDot')
  const label = document.getElementById('statusText')
  dot.className   = 'status-dot ' + type
  label.textContent = text
}

// ── Supabase Fetch ────────────────────────────────────────────────
async function sbFetch(path, method = 'GET', body) {
  const { supabaseSession } = await getAuth()
  const token = supabaseSession?.access_token
  if (!token) return null

  const res = await fetch(SUPABASE_URL + '/rest/v1/' + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_KEY,
      'Authorization': 'Bearer ' + token,
      'Prefer': method === 'POST' ? 'return=representation,resolution=merge-duplicates' : '',
    },
    body: body ? JSON.stringify(body) : undefined,
  })
  if (!res.ok) return null
  return res.json().catch(() => null)
}

// ── Profil aus aktivem Tab holen ──────────────────────────────────
async function getProfileFromTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0]
      if (!tab?.url?.includes('linkedin.com/in/')) {
        resolve(null)
        return
      }
      chrome.tabs.sendMessage(tab.id, { type: 'SCRAPE_PROFILE' }, (response) => {
        if (chrome.runtime.lastError || !response?.profile) {
          resolve(null)
          return
        }
        resolve(response.profile)
      })
    })
  })
}

// ── Profil-Card anzeigen ──────────────────────────────────────────
function showProfile(profile) {
  const name    = profile.name || `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || 'Unbekannt'
  const title   = profile.job_title || profile.headline || ''
  const company = profile.company || ''
  const avatar  = profile.avatar_url

  document.getElementById('profileName').textContent    = name
  document.getElementById('profileTitle').textContent   = title
  document.getElementById('profileCompany').textContent = company

  const avatarEl = document.getElementById('profileAvatar')
  if (avatar && avatar.startsWith('http')) {
    avatarEl.innerHTML = `<img src="${avatar}" alt="${name}" onerror="this.parentElement.textContent='${name[0]?.toUpperCase() || '?'}'"/>`
  } else {
    avatarEl.textContent = name[0]?.toUpperCase() || '?'
  }
}

// ── Import ausführen ──────────────────────────────────────────────
window.importLead = async function() {
  if (!currentProfile || !currentUserId) return

  const btn = document.getElementById('importBtn')
  btn.disabled = true
  btn.className = 'btn-import'
  btn.innerHTML = `<div class="spinner"></div> Importiere...`

  try {
    const payload = { ...currentProfile, user_id: currentUserId }
    const result  = await sbFetch(
      'leads?on_conflict=user_id,linkedin_url',
      'POST',
      [payload]
    )

    if (result !== null) {
      const isNew = Array.isArray(result) && result.length > 0
      btn.className = 'btn-import success'
      btn.innerHTML = isNew
        ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg> Erfolgreich importiert!`
        : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg> Bereits in Leadesk`

      setStatus('connected', isNew ? 'Lead importiert ✓' : 'Bereits vorhanden ✓')
    } else {
      throw new Error('Speichern fehlgeschlagen')
    }
  } catch(err) {
    btn.className = 'btn-import error'
    btn.innerHTML = `⚠ Fehler — bitte neu versuchen`
    setStatus('error', 'Import fehlgeschlagen')

    setTimeout(() => {
      btn.disabled = false
      btn.className = 'btn-import'
      btn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
          <polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/>
          <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
        </svg>
        Nochmal versuchen
      `
    }, 2500)
  }
}

// ── Navigation ────────────────────────────────────────────────────
window.openDashboard = function() {
  chrome.tabs.create({ url: DASHBOARD })
}
window.openLeads = function() {
  chrome.tabs.create({ url: DASHBOARD + '/leads' })
}

// ── Auth aus Leadesk-Tab lesen ────────────────────────────────────
async function syncAuthFromLeadesk() {
  return new Promise((resolve) => {
    chrome.tabs.query({}, (tabs) => {
      const leaTab = tabs.find(t => t.url?.includes('app.leadesk.de') || t.url?.includes('leadesk.de'))
      if (!leaTab) { resolve(false); return }

      chrome.scripting.executeScript({
        target: { tabId: leaTab.id },
        func: () => {
          const key = Object.keys(localStorage).find(k => k.includes('auth-token'))
          if (!key) return null
          try {
            const data = JSON.parse(localStorage.getItem(key))
            return { session: data, userId: data?.user?.id }
          } catch { return null }
        }
      }, (results) => {
        if (chrome.runtime.lastError || !results?.[0]?.result) { resolve(false); return }
        const { session, userId } = results[0].result
        if (session && userId) {
          chrome.storage.local.set({ supabaseSession: session, userId }, () => resolve(true))
        } else {
          resolve(false)
        }
      })
    })
  })
}

// ── Init ──────────────────────────────────────────────────────────
async function init() {
  setStatus('', 'Prüfe Status...')

  // Auth aus gespeichertem Storage
  let { supabaseSession, userId } = await getAuth()

  // Falls nicht vorhanden: aus Leadesk-Tab holen
  if (!supabaseSession || !userId) {
    const synced = await syncAuthFromLeadesk()
    if (synced) {
      const auth = await getAuth()
      supabaseSession = auth.supabaseSession
      userId = auth.userId
    }
  }

  if (!supabaseSession || !userId) {
    setStatus('error', 'Nicht eingeloggt')
    hide('profileFound')
    hide('notOnProfile')
    show('notLoggedIn')
    return
  }

  currentUserId = userId
  setStatus('connected', 'Eingeloggt ✓')

  // Prüfe ob auf LinkedIn-Profil
  const profile = await getProfileFromTab()

  if (!profile) {
    hide('notLoggedIn')
    hide('profileFound')
    show('notOnProfile')
    setStatus('connected', 'Eingeloggt — kein Profil offen')
    return
  }

  currentProfile = profile
  hide('notLoggedIn')
  hide('notOnProfile')
  show('profileFound')
  showProfile(profile)
  setStatus('connected', 'Profil erkannt ✓')
}

init()
